import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Schedule } from './Schedule';

@Component({
  selector: 'app-find-class',
  templateUrl: './find-class.component.html',
  styleUrls: ['./find-class.component.css']
})
export class FindClassComponent implements OnInit {
  scheduleClass:Schedule[]
  classes: string[] = ['1','2','3','4','5','6','7','8','9','10','11','12'];
  subjects: string[] = ['Hindi','English','Maths','Environment','History',
  'Geography','Civics','Sanskrit','Physics','Chemistry','Biology','Accounts'];
  
  selectClass:FormGroup;
  selectSubject:FormGroup;

  schedule=new Schedule();
  
  constructor() { }

  ngOnInit(): void {
  }
  onClick(){

  }

}
