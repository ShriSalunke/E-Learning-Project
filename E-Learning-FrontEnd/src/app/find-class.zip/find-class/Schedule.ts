export class Schedule
{
   public classname:string;
 

}
