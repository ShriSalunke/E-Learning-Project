export class Schedule
{
    classname:string;
    subject:string;
constructor()
{
    
}

}
